package main;

import java.util.Scanner;

public class Public {
	public static Scanner sc = new Scanner(System.in);
	
	public void cls() {
		for (int i = 0; i < 40; i++) {
			System.out.println();
			System.out.println();
		}
	}
	
	public void enter() {
		System.out.println("Please press enter to continue..");
		sc.nextLine();
	}

	
	public Public() {
		// TODO Auto-generated constructor stub
	}

}
